set arrays 72 lines 110 head off tab off pages 0
SELECT * FROM TABLE(moats.top(5));