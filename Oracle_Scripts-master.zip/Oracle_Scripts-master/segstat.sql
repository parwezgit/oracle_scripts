@@segstat2 "&1" "&2" "&3"
