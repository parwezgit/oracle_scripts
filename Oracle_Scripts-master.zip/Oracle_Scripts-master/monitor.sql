-- read from sql_monitor
-- Luca March 2012
set linesize 200
@@monitor_details status='EXECUTING'

