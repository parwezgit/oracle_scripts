set linesize 200
column owner format a20
column table_name format a32
set verify off
@@tab2 "%&1%"
