PRO Please Wait ...
DEF skip_tcb=''
DEF from_edb360=''
@@sql/sqld360_0a_main.sql
HOS unzip -l &&sqld360_main_filename._&&sqld360_file_time.
