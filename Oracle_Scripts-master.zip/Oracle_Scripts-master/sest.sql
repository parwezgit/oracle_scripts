select * from v$sess_time_model where sid in (&1);
