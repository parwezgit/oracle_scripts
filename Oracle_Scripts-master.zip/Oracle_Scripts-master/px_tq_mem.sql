set feed on
set echo on
set head on
select * from v$sgastat where name ='PX msg pool';
