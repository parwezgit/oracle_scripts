# Oracle_Scripts

Refer help.sql file.
