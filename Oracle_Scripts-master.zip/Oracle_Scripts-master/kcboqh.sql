PROMPT Calling segcached.sql
@@segcached "&1"

