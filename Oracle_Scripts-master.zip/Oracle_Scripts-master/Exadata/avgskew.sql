select avg(pk_col) from kso.skew
where col1 > 0
/
