@find_trace
alter system dump datafile &fileno block &blockno;
