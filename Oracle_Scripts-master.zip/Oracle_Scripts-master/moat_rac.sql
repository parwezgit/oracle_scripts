set lines 190 pages 0 arraysize 47
select * from table(jss.gtop) ;